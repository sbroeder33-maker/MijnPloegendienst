# MijnPloegendienst

Nieuwe Android-basis voor MijnPloegendienst.

Functies in versie 1:
- Werkende onderste navigatie
- Home
- Uren
- Rooster
- Loon
- Instellingen

Volgende stap: echte gegevens opslaan en loon/uren volledig instelbaar maken.
