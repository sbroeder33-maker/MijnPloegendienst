# MijnPloegendienst V2

Versie 1.1 met echte Android Buttons voor de onderste navigatie. Alle vijf knoppen hebben een eigen click listener.
