package nl.mijnploegendienst;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(6,21,34);
    private static final int CARD = Color.rgb(16,37,54);
    private static final int LINE = Color.rgb(41,66,88);
    private static final int TEXT = Color.rgb(246,248,251);
    private static final int MUTED = Color.rgb(158,176,192);
    private static final int BLUE = Color.rgb(22,131,255);
    private static final int GREEN = Color.rgb(25,200,117);
    private static final int ORANGE = Color.rgb(255,138,31);

    private LinearLayout root, content;
    private Calendar month = Calendar.getInstance();
    private SharedPreferences sp;
    private JSONArray shifts = new JSONArray();
    private double salary = 4480.49, rate = 26.68, schedule = 15.06, bhv = 12.50, reimb = 118.45, deduction = 28.63;
    private final double[] mult = {1.30,1.50,1.50,2.00,2.00};
    private final String[] names = {"Dagdienst","Avonddienst","Zaterdag","Nachtdienst","Zondag"};
    private int pad;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        pad = dp(14);
        sp = getSharedPreferences("mijn_ploegendienst", MODE_PRIVATE);
        load();
        buildShell();
        home();
    }

    private void load() {
        salary = sp.getFloat("salary", 4480.49f);
        rate = sp.getFloat("rate", 26.68f);
        schedule = sp.getFloat("schedule", 15.06f);
        bhv = sp.getFloat("bhv", 12.50f);
        reimb = sp.getFloat("reimb", 118.45f);
        deduction = sp.getFloat("deduction", 28.63f);
        try { shifts = new JSONArray(sp.getString("shifts", "[]")); }
        catch (Exception e) { shifts = new JSONArray(); }
    }

    private void save() {
        sp.edit()
            .putFloat("salary", (float) salary)
            .putFloat("rate", (float) rate)
            .putFloat("schedule", (float) schedule)
            .putFloat("bhv", (float) bhv)
            .putFloat("reimb", (float) reimb)
            .putFloat("deduction", (float) deduction)
            .putString("shifts", shifts.toString())
            .apply();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(TEXT);
        t.setTextSize(size);
        return t;
    }

    private GradientDrawable box(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), LINE);
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(margin, margin, margin, margin);
        return p;
    }

    private TextView button(String label) {
        TextView t = text(label, 16);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(null, 1);
        t.setPadding(pad, pad, pad, pad);
        t.setBackground(box(BLUE, 13));
        return t;
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(pad, dp(20), pad, dp(16));
        head.setBackgroundResource(R.drawable.bg_header);
        TextView h = text("Mijn Ploegendienst", 26);
        h.setTypeface(null, 1);
        head.addView(h);
        TextView sub = text("Jouw uren. Jouw verdienen. Altijd inzicht.", 13);
        sub.setTextColor(MUTED);
        head.addView(sub);
        root.addView(head, new LinearLayout.LayoutParams(-1, dp(100)));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, 0, pad, pad);
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, dp(6), 0, dp(6));
        nav.setBackgroundColor(Color.rgb(8,24,39));
        String[] labels = {"Home", "Uren", "Overzicht", "Instellingen"};
        for (int i = 0; i < labels.length; i++) {
            TextView t = text(labels[i], 12);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(MUTED);
            final int page = i;
            t.setOnClickListener(v -> { if (page == 0) home(); else if (page == 1) add(); else if (page == 2) overview(); else settings(); });
            nav.addView(t, new LinearLayout.LayoutParams(0, dp(58), 1));
        }
        root.addView(nav);
    }

    private void clear() { content.removeAllViews(); }

    private void monthBar() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView prev = text("‹", 32);
        TextView label = text(new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(month.getTime()), 18);
        label.setGravity(Gravity.CENTER);
        label.setTypeface(null, 1);
        TextView next = text("›", 32);
        prev.setGravity(Gravity.CENTER);
        next.setGravity(Gravity.CENTER);
        prev.setOnClickListener(v -> { month.add(Calendar.MONTH, -1); home(); });
        next.setOnClickListener(v -> { month.add(Calendar.MONTH, 1); home(); });
        row.addView(prev, new LinearLayout.LayoutParams(dp(55), dp(55)));
        row.addView(label, new LinearLayout.LayoutParams(0, dp(55), 1));
        row.addView(next, new LinearLayout.LayoutParams(dp(55), dp(55)));
        content.addView(row);
    }

    private void home() {
        clear(); monthBar();
        double hours = 0, extra = 0;
        for (int i = 0; i < shifts.length(); i++) {
            try { JSONObject o = shifts.getJSONObject(i); if (sameMonth(o.getString("date"))) { hours += o.getDouble("hours"); extra += extra(o); } }
            catch (Exception ignored) { }
        }
        double fixed = salary * (1 + schedule / 100.0) + bhv;
        double gross = fixed + extra;
        double net = gross * (1 - deduction / 100.0) + reimb;

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(metric("Geschat bruto", money(gross), GREEN), new LinearLayout.LayoutParams(0, dp(88), 1));
        row1.addView(metric("Geschat netto", money(net), BLUE), new LinearLayout.LayoutParams(0, dp(88), 1));
        content.addView(row1, lp(-1, dp(88), 0));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(metric("Extra uren", fmt(hours), Color.rgb(170,155,255)), new LinearLayout.LayoutParams(0, dp(88), 1));
        row2.addView(metric("Extra bruto", money(extra), ORANGE), new LinearLayout.LayoutParams(0, dp(88), 1));
        content.addView(row2, lp(-1, dp(88), 0));

        TextView add = button("+ Extra uren / inkomsten toevoegen");
        add.setOnClickListener(v -> add());
        content.addView(add, lp(-1, dp(52), pad));

        section("Vaste loonbasis");
        item("Basissalaris", "Volgens loonstrook", money(salary));
        item("Schematoeslag " + fmt(schedule) + "%", "Automatisch berekend", money(salary * schedule / 100));
        item("BHV/EHBO vergoeding", "Vaste bruto vergoeding", money(bhv));

        section("Deze maand toegevoegd");
        boolean any = false;
        for (int i = shifts.length() - 1; i >= 0; i--) {
            try {
                JSONObject o = shifts.getJSONObject(i);
                if (sameMonth(o.getString("date"))) {
                    any = true;
                    int type = Math.max(0, Math.min(4, o.getInt("type")));
                    item(o.getString("date"), names[type] + " · " + fmt(o.getDouble("hours")) + " uur · " + Math.round(mult[type] * 100) + "%", money(extra(o)));
                }
            } catch (Exception ignored) { }
        }
        if (!any) notice("Nog geen extra uren voor deze maand.");
    }

    private LinearLayout metric(String label, String value, int color) {
        LinearLayout x = new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setPadding(pad, pad, pad, pad);
        x.setBackground(box(CARD, 15));
        TextView a = text(label, 12); a.setTextColor(MUTED); x.addView(a);
        TextView b = text(value, 20); b.setTypeface(null, 1); b.setTextColor(color); x.addView(b);
        return x;
    }

    private EditText edit(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(MUTED); e.setText(value); e.setTextColor(TEXT); e.setSingleLine(true);
        e.setPadding(pad, 0, pad, 0); e.setBackground(box(Color.rgb(9,26,40), 10));
        e.setLayoutParams(lp(-1, dp(52), 4));
        return e;
    }

    private void add() {
        clear(); section("Extra uren / inkomsten");
        EditText date = edit("Datum (YYYY-MM-DD)", new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()));
        content.addView(date);
        Spinner type = new Spinner(this);
        String[] types = {"Dagdienst — 130%", "Avonddienst — 150%", "Zaterdag — 150%", "Nachtdienst — 200%", "Zondag — 200%"};
        type.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, types));
        content.addView(type, lp(-1, dp(50), 4));
        EditText hours = edit("Aantal uren", "2"); content.addView(hours);
        notice("De extra uren worden berekend met jouw basisuurloon en het gekozen percentage.");
        TextView save = button("Opslaan");
        save.setOnClickListener(v -> {
            try {
                double h = Double.parseDouble(hours.getText().toString().replace(',', '.'));
                if (h <= 0) throw new Exception();
                JSONObject o = new JSONObject();
                o.put("date", date.getText().toString().trim());
                o.put("type", type.getSelectedItemPosition());
                o.put("hours", h);
                shifts.put(o); save(); home();
            } catch (Exception e) { Toast.makeText(this, "Vul datum en uren goed in.", Toast.LENGTH_SHORT).show(); }
        });
        content.addView(save, lp(-1, dp(52), pad));
        TextView cancel = text("Annuleren", 15); cancel.setGravity(Gravity.CENTER); cancel.setPadding(pad,pad,pad,pad); cancel.setOnClickListener(v -> home()); content.addView(cancel, lp(-1, dp(50), 0));
    }

    private void overview() {
        clear(); monthBar();
        double hours = 0, extra = 0;
        for (int i = 0; i < shifts.length(); i++) try { JSONObject o=shifts.getJSONObject(i); if (sameMonth(o.getString("date"))) { hours += o.getDouble("hours"); extra += extra(o); } } catch (Exception ignored) { }
        double fixed = salary * (1 + schedule / 100.0) + bhv;
        double gross = fixed + extra;
        double net = gross * (1 - deduction / 100.0);
        section("Maandoverzicht");
        item("Vaste brutobasis", "Basissalaris + schematoeslag + BHV", money(fixed));
        item("Extra bruto", fmt(hours) + " extra uren", money(extra));
        item("Totaal geschat bruto", "", money(gross));
        item("Geschat nettoloon", "Na geschatte inhouding", money(net));
        item("Netto vergoeding", "Reiskosten/overige vergoeding", money(reimb));
        item("Geschat uitbetaald", "", money(net + reimb));
        section("Per soort");
        for (int t=0;t<5;t++) {
            double h=0,g=0;
            for (int i=0;i<shifts.length();i++) try { JSONObject o=shifts.getJSONObject(i); if (sameMonth(o.getString("date")) && o.getInt("type")==t) { h+=o.getDouble("hours"); g+=extra(o); } } catch (Exception ignored) { }
            item(names[t], fmt(h) + " uur · " + Math.round(mult[t]*100) + "%", money(g));
        }
    }

    private void settings() {
        clear(); section("Jouw looninstellingen");
        EditText a=edit("Bruto basissalaris",String.valueOf(salary)); content.addView(a);
        EditText b=edit("Basis uurloon",String.valueOf(rate)); content.addView(b);
        EditText c=edit("Schematoeslag %",String.valueOf(schedule)); content.addView(c);
        EditText d=edit("BHV/EHBO bruto",String.valueOf(bhv)); content.addView(d);
        EditText e=edit("Netto vergoedingen",String.valueOf(reimb)); content.addView(e);
        EditText f=edit("Geschatte inhouding %",String.valueOf(deduction)); content.addView(f);
        notice("De netto-uitkomst is een schatting en vervangt geen officiële loonberekening.");
        TextView save = button("Instellingen opslaan");
        save.setOnClickListener(v -> { try { salary=num(a); rate=num(b); schedule=num(c); bhv=num(d); reimb=num(e); deduction=num(f); save(); home(); } catch(Exception ex) { Toast.makeText(this,"Controleer de bedragen.",Toast.LENGTH_SHORT).show(); } });
        content.addView(save, lp(-1,dp(52),pad));
        TextView del=text("Wis alle extra uren",15); del.setTextColor(Color.rgb(255,110,110)); del.setGravity(Gravity.CENTER); del.setPadding(pad,pad,pad,pad);
        del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Alles wissen?").setMessage("Alle ingevoerde extra uren worden verwijderd.").setNegativeButton("Annuleren",null).setPositiveButton("Wissen",(d1,w)->{shifts=new JSONArray();save();home();}).show());
        content.addView(del,lp(-1,dp(50),0));
    }

    private double num(EditText e) { return Double.parseDouble(e.getText().toString().trim().replace(',','.')); }
    private void section(String s) { TextView t=text(s,18); t.setTypeface(null,1); t.setPadding(pad,pad,pad,dp(8)); content.addView(t); }
    private void item(String a,String b,String c) { LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(pad,pad,pad,pad); r.setBackground(box(Color.rgb(11,29,44),12)); LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); TextView x=text(a,14);x.setTypeface(null,1);tx.addView(x);TextView y=text(b,12);y.setTextColor(MUTED);tx.addView(y);r.addView(tx,new LinearLayout.LayoutParams(0,-2,1));TextView z=text(c,14);z.setTypeface(null,1);r.addView(z);content.addView(r,lp(-1,dp(64),4)); }
    private void notice(String s) { TextView t=text(s,12); t.setTextColor(MUTED); t.setPadding(pad,pad,pad,pad); t.setBackground(box(Color.rgb(17,38,56),12)); content.addView(t,lp(-1,-2,8)); }
    private boolean sameMonth(String d) { return d != null && d.length() >= 7 && d.substring(0,7).equals(new SimpleDateFormat("yyyy-MM",Locale.US).format(month.getTime())); }
    private double extra(JSONObject o) { try { int type=Math.max(0,Math.min(4,o.getInt("type"))); return o.getDouble("hours")*rate*mult[type]; } catch(Exception e) { return 0; } }
    private String money(double x) { return String.format(Locale.GERMANY,"€ %,.2f",x).replace(',','X').replace('.',',').replace('X','.'); }
    private String fmt(double x) { return String.format(Locale.GERMANY,"%.2f",x).replace('.',','); }
}
