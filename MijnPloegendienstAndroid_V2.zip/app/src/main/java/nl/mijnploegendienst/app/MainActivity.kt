package nl.mijnploegendienst.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private val blue = Color.rgb(25,118,210)
    private val dark = Color.rgb(35,42,50)
    private val muted = Color.rgb(100,110,120)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        showPage(0)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245,247,250))
            fitsSystemWindows = true
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20),dp(18),dp(20),dp(8))
        }
        root.addView(content, LinearLayout.LayoutParams(-1,0,1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
            isClickable = false
        }

        val labels = arrayOf("⌂\nHome","◷\nUren","▣\nRooster","€\nLoon","⚙\nInst.")
        labels.forEachIndexed { i, label ->
            val b = Button(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                isAllCaps = false
                setPadding(0,0,0,0)
                minHeight = 0
                minWidth = 0
                setTextColor(if (i == 0) blue else muted)
                setBackgroundColor(Color.TRANSPARENT)
                isClickable = true
                isFocusable = true
                setOnClickListener { showPage(i) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0,dp(72),1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1,dp(74)))
        setContentView(root)
    }

    private fun showPage(page:Int) {
        content.removeAllViews()
        when(page) {
            0 -> { title("Home","MijnPloegendienst"); card("Huidige dienst","Vandaag · 07:00 – 15:00","Dagdienst"); card("Volgende dienst","Morgen · 15:00 – 23:00","Middagdienst") }
            1 -> { title("Uren","Je gewerkte uren"); action("＋ Uren toevoegen"); card("Deze maand","Gewerkte uren","168 uur"); card("Vandaag","07:00 – 15:00 · 30 min pauze","7,5 uur") }
            2 -> { title("Rooster","Je ploegendienst"); card("Vandaag","Zaterdag 6 september","Dagdienst"); card("Morgen","Zondag 7 september","Middagdienst"); card("Maandag","8 september","Nachtdienst") }
            3 -> { title("Loon","Deze maand"); card("Bruto basisloon","Basisloon","€ 4.480"); card("Ploegentoeslag","15,06%","€ 675"); card("Geschat netto","Indicatie","€ 3.800") }
            4 -> { title("Instellingen","Persoonlijke instellingen"); action("Uurloon instellen"); action("Ploegentoeslag instellen"); action("Profiel instellen") }
        }
    }

    private fun title(a:String,b:String) { text(a,28f,dark,true); text(b,14f,muted); space(14) }

    private fun card(a:String,b:String,c:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));setBackgroundColor(Color.WHITE);elevation=dp(2).toFloat()}
        addText(box,a,16f,dark,true); addText(box,b,13f,muted); addText(box,c,19f,blue,true)
        val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));content.addView(box,lp)
    }
    private fun action(label:String) {
        val b=Button(this).apply{text=label;isAllCaps=false;setOnClickListener{Toast.makeText(context,"Deze functie bouwen we als volgende stap.",Toast.LENGTH_SHORT).show()}}
        content.addView(b,LinearLayout.LayoutParams(-1,dp(52)))
    }
    private fun text(s:String,z:Float,c:Int,b:Boolean=false)=addText(content,s,z,c,b)
    private fun addText(p:LinearLayout,s:String,z:Float,c:Int,b:Boolean=false){TextView(this).apply{text=s;textSize=z;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD}.also{p.addView(it)}}
    private fun space(x:Int){content.addView(Space(this),LinearLayout.LayoutParams(1,dp(x)))}
    private fun dp(x:Int)= (x*resources.displayMetrics.density).toInt()
}
