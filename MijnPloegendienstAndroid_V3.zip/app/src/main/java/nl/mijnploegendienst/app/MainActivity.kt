package nl.mijnploegendienst.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private val blue = Color.rgb(30, 136, 229)
    private val dark = Color.rgb(35, 42, 50)
    private val muted = Color.rgb(110, 120, 130)
    private val bg = Color.rgb(245, 247, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showApp()
        showHome()
    }

    private fun showApp() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(10))
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }

        val items = listOf(
            "⌂" to "Home",
            "◷" to "Uren",
            "▣" to "Rooster",
            "€" to "Loon",
            "⚙" to "Inst."
        )
        items.forEachIndexed { index, pair ->
            val b = TextView(this).apply {
                text = "${pair.first}\n${pair.second}"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (index == 0) blue else muted)
                setPadding(0, dp(6), 0, dp(4))
                isClickable = true
                isFocusable = true
                setOnClickListener { select(index) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
        }

        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))
        setContentView(root)
    }

    private fun select(index: Int) {
        when (index) {
            0 -> showHome()
            1 -> showHours()
            2 -> showSchedule()
            3 -> showPay()
            4 -> showSettings()
        }
    }

    private fun base(title: String, subtitle: String? = null) {
        content.removeAllViews()
        text(title, 28f, dark, true)
        if (subtitle != null) text(subtitle, 14f, muted)
        space(14)
    }

    private fun showHome() {
        base("Goedemorgen 👋", "MijnPloegendienst")
        card("Huidige dienst", "Vandaag · 07:00 – 15:00", "Dagdienst")
        card("Volgende dienst", "Morgen · 15:00 – 23:00", "Middagdienst")
        rowStats("Deze maand", "168 uur", "Geschat loon", "€ 3.800")
    }

    private fun showHours() {
        base("Uren", "Overzicht van je gewerkte uren")
        button("+ Uren toevoegen") { toast("Hier kun je straks een dienst toevoegen.") }
        space(8)
        card("Vandaag", "07:00 – 15:00 · 30 min pauze", "7,5 uur")
        card("Gisteren", "15:00 – 23:00 · 30 min pauze", "7,5 uur")
        card("Totaal deze maand", "Gewerkte uren", "168 uur")
    }

    private fun showSchedule() {
        base("Rooster", "Je ploegendienst")
        card("Vandaag", "Zaterdag 6 september", "Dagdienst · 07:00 – 15:00")
        card("Morgen", "Zondag 7 september", "Middagdienst · 15:00 – 23:00")
        card("Maandag", "8 september", "Nachtdienst · 23:00 – 07:00")
        button("Rooster aanpassen") { toast("Rooster aanpassen komt hier.") }
    }

    private fun showPay() {
        base("Loon", "Berekening van deze maand")
        card("Bruto basisloon", "Op basis van je uurloon", "€ 4.480")
        card("Ploegentoeslag", "Ingesteld percentage", "15,06%")
        card("Geschat netto", "Indicatie", "€ 3.800")
        button("Looninstellingen") { toast("Hier kun je uurloon en toeslagen instellen.") }
    }

    private fun showSettings() {
        base("Instellingen", "Persoonlijke instellingen")
        card("Uurloon", "Basis voor je loonberekening", "Instellen")
        card("Ploegentoeslag", "Toeslagpercentage", "Instellen")
        card("Naam", "Weergave in de app", "Instellen")
        button("Opslaan") { toast("Instellingen opgeslagen.") }
    }

    private fun card(title: String, detail: String, value: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.WHITE)
            elevation = dp(2).toFloat()
        }
        textInto(box, title, 16f, dark, true)
        textInto(box, detail, 13f, muted)
        textInto(box, value, 19f, blue, true)
        val lp = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(10))
        content.addView(box, lp)
    }

    private fun rowStats(a: String, av: String, b: String, bv: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = stat(a, av)
        val right = stat(b, bv)
        row.addView(left, LinearLayout.LayoutParams(0, dp(100), 1f))
        row.addView(right, LinearLayout.LayoutParams(0, dp(100), 1f))
        content.addView(row)
    }

    private fun stat(label: String, value: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
        }
        textInto(box, label, 13f, muted)
        textInto(box, value, 20f, dark, true)
        return box
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }
        content.addView(b, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) {
        textInto(content, s, size, color, bold)
    }

    private fun textInto(parent: LinearLayout, s: String, size: Float, color: Int, bold: Boolean = false) {
        val v = TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        parent.addView(v)
    }

    private fun space(px: Int) {
        content.addView(Space(this), LinearLayout.LayoutParams(1, dp(px)))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
